import java.util.ArrayList;
import java.util.List;

public class Method {
    private final String methodName;
    private final List<String> argumentTypes = new ArrayList<>();

    public Method(String methodName) {
        this.methodName = methodName;
    }

    public void addArgumentType(String type) {
        argumentTypes.add(type);
    }

    /**
     * Comment.
     */
    @Override
    public String toString() {
        if (argumentTypes.size() == 0) {
            return methodName + "()";
        }
        String res = methodName + "(";
        for (int i = 0; i < argumentTypes.size(); i++) {
            if (i != argumentTypes.size() - 1) {
                res += argumentTypes.get(i) + ",";
            } else {
                res += argumentTypes.get(i) + ")";
            }
        }
        return res;
    }
}

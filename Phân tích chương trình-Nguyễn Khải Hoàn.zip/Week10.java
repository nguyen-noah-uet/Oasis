import java.util.ArrayList;
import java.util.List;

public class Week10 {
    ArrayList<String> imports = new ArrayList<>();

    /**
     * Comment.
     */
    public List<String> getAllFunctions(String fileContent) {
        imports.clear();
        return getStaticFunction(fileContent);
    }

    /**
     * Comment.
     */
    public ArrayList<String> getStaticFunction(String content) {
        content = removeComment(content);
        content = minimize(content);

        ArrayList<String> lines = splitByLine(content);
        getImport(lines);
        lines = getStatic(lines);

        lines = removeNewLineChar(lines);
        ArrayList<String> ret = new ArrayList<>();
        //  Lấy tên và đối số
        for (int i = 0; i < lines.size(); ++i) {
            boolean error = false;
            try {
                lines.set(i, getMethodNameAndArgs(lines.get(i)));
                lines.set(i, convertToMethodSignature(lines.get(i)));
            } catch (Exception e) {
                error = true;
            }
            if (!error) {
                ret.add(lines.get(i));
            }
        }
        return ret;
    }

    /**
     * Comment.
     */
    public String minimize(String content) {
        ArrayList<Integer> indexArray = new ArrayList<Integer>();
        ArrayList<Integer> removeIndex = new ArrayList<>();

        for (int i = 0; i < content.length(); ++i) {
            if (content.charAt(i) == '(') {
                indexArray.add(i);
            } else if (content.charAt(i) == ')') {
                for (int j = indexArray.get(indexArray.size() - 1); j <= i; ++j) {
                    if (content.charAt(j) == '\n') {
                        removeIndex.add(j);
                    }
                }
                indexArray.remove(indexArray.size() - 1);
            }
        }

        StringBuilder stringBuilder = new StringBuilder(content);
        for (int i = 0; i < removeIndex.size(); ++i) {
            stringBuilder.setCharAt(removeIndex.get(i), ' ');
            //stringBuilder.deleteCharAt(removeIndex.get(i));
        }
        return stringBuilder.toString();
    }


    /**
     * Comment.
     */
    public String removeComment(String content) {
        StringBuilder stringBuilder = new StringBuilder(content);
        //  Xóa comment nhiều dòng
        while (stringBuilder.toString().contains("/*")) {
            int startIndex = stringBuilder.indexOf("/*");
            int endIndex = stringBuilder.indexOf("*/");
            /*
            while (stringBuilder.indexOf("/*", startIndex + 2) != -1
                    && stringBuilder.indexOf("/*", startIndex + 2) < endIndex - 2) {
                startIndex = stringBuilder.indexOf("/*", startIndex + 2);
            }
            */
            stringBuilder.delete(startIndex, endIndex + 2);
        }
        // Xóa comment 1 dòng
        while (stringBuilder.toString().contains("//")) {
            int startIndex = stringBuilder.indexOf("//");
            int endIndex = startIndex;
            while (stringBuilder.charAt(endIndex) != '\n') {
                ++endIndex;
            }
            stringBuilder.delete(startIndex, endIndex + 1);
        }
        return stringBuilder.toString();
    }

    /**
     * Comment.
     */
    public ArrayList<String> splitByLine(String content) {
        ArrayList<String> ret = new ArrayList<>();
        String[] result = content.split("\n");
        for (int i = 0; i < result.length; ++i) {
            ret.add(result[i]);
        }
        return ret;
    }

    /**
     * Comment.
     */
    public ArrayList<String> getStatic(ArrayList<String> lines) {
        for (int i = 0; i < lines.size();) {
            if (!lines.get(i).contains("static")
                    || !lines.get(i).contains("{")) {
                lines.remove(i);
            } else {
                ++i;
            }
        }
        return lines;
    }

    /**
     * Comment.
     */
    public void getImport(ArrayList<String> list) {
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i).contains("import")) {
                list.set(i, list.get(i).trim());
                String[] splitResult = list.get(i).split(" ");
                imports.add(splitResult[splitResult.length - 1]);
            }
        }
        for (int i = 0; i < imports.size(); ++i) {
            StringBuilder stringBuilder = new StringBuilder(imports.get(i));
            if (stringBuilder.toString().contains(";")) {
                stringBuilder.deleteCharAt(stringBuilder.indexOf(";"));
            }
            imports.set(i, stringBuilder.toString());
        }
        imports.add("com.nordstrom.common.jdbc.utils.QueryAPI");
        imports.add("com.nordstrom.common.jdbc.utils.SProcAPI");
    }

    /**
     * Comment.
     */
    public ArrayList<String> removeNewLineChar(ArrayList<String> lines) {
        for (int i = 0; i < lines.size(); ++i) {
            lines.set(i, lines.get(i).trim());
        }
        return lines;
    }

    /**
     * Comment.
     */
    public String getMethodNameAndArgs(String method) {
        String ret = "";
        int index = method.indexOf("(");
        //  Lấy từ dấu ( đến khi gặp dấu cách
        for (int i = index; method.charAt(i) != ' '; --i) {
            ret = method.charAt(i) + ret;
        }
        //  Lấy từ sau dấu ( đến khi gặp dấu )
        for (int i = index + 1; method.charAt(i) != ')'; ++i) {
            ret = ret +  method.charAt(i);
        }
        ret = ret + ")";
        return ret;
    }

    /**
     * Comment.
     */
    public ArrayList<String> getArgument(String method) {
        ArrayList<String> args = new ArrayList<String>();
        int startIndex = method.indexOf('(');
        int endIndex = method.indexOf(')');
        method = method.substring(startIndex + 1, endIndex);
        method = method.trim();

        String[] argArray = method.split(",");
        for (int i = 0; i < argArray.length; ++i) {
            argArray[i] = argArray[i].trim();
            if (argArray[i].contains("...")) {
                argArray[i] = argArray[i].substring(0, argArray[i].indexOf("..."));
            }
            args.add(argArray[i].split(" ")[0]);
        }
        return args;
    }

    /**
     *  Lấy tên đầy đủ của kiểu dữ liệu.
     */
    public String getTypeFullName(String type) {
        if (type.equals("int") || type.equals("double") || type.equals("char")
                || type.equals("float") || type.equals("long") || type.equals("boolean")
                || type.equals("short") || type.equals("byte") || type.equals("T[]")
                || type.equals("T") || type.equals("?")) {
            return type;
        }

        if (type.contains("<")) {
            String firstType = type.split("<")[0];
            String secondType = type.split("<")[1].split(">")[0];
            return getTypeFullName(firstType) + "<" + getTypeFullName(secondType) + ">";
        }

        for (int i = 0; i < imports.size(); ++i) {
            if (imports.get(i).contains(type)
                    && imports.get(i).indexOf("." + type) + type.length() + 1
                    == imports.get(i).length()
                    || imports.get(i).contains(type + ".")) {
                String importType = imports.get(i);
                return importType.substring(0, importType.indexOf(type)) + type;
            }
        }

        imports.add("java.lang." + type);
        return "java.lang." + type;
    }

    /**
     * Comment.
     */
    public String convertToMethodSignature(String method) {
        ArrayList<String> args = getArgument(method);
        String methodName = method.substring(0, method.indexOf('('));

        String ret = methodName + "(";
        for (int i = 0; i < args.size(); ++i) {
            ret += getTypeFullName(args.get(i));
            if (i < args.size() - 1) {
                ret += ",";
            }
        }
        ret += ")";
        return ret;
    }
}



import java.util.ArrayList;
import java.util.List;

public class Layer {
    private final List<Shape> shapes;

    public Layer() {
        this.shapes = new ArrayList<>();
    }

    /**
     * Add a shape to list.
     *
     * @param shape shape
     */
    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    /**
     * Remove all circles.
     */
    public void removeCircles() {
        shapes.removeIf(shape -> shape instanceof Circle);
    }

    /**
     * Get info of layer.
     *
     * @return String
     */
    public String getInfo() {
        String info = "Layer of crazy shapes:\n";
        for (Shape shape : shapes) {
            info += shape.toString() + "\n";
        }
        return info;
    }

    /**
     * Remove duplicate shapes in layer.
     */
    public void removeDuplicates() {
        if (shapes.size() < 2) {
            return;
        }
        for (int i = 0; i < shapes.size() - 1; i++) {
            for (int j = i + 1; j < shapes.size(); j++) {
                if (shapes.get(j).equals(shapes.get(i))) {
                    shapes.remove(j);
                }
            }
        }
    }
}

public class Square extends Rectangle {

    /**
     * Constructor.
     */
    public Square() {
    }

    /**
     * Constructor.
     */
    public Square(double side) {
        super(side, side);
    }

    /**
     * Constructor.
     */
    public Square(double side, String color, boolean filled) {
        super(side, side, color, filled);
    }

    /**
     * Constructor.
     */
    public Square(Point topLeft, double side, String color, boolean filled) {
        super(topLeft, side, side, color, filled);
    }

    public double getSide() {
        return width;
    }

    /**
     * Set side for the square.
     *
     * @param side side
     */
    public void setSide(double side) {
        super.setLength(side);
        super.setWidth(side);
    }

    /**
     * Set side for the square.
     *
     * @param length side
     */
    @Override
    public void setLength(double length) {
        super.setLength(length);
        super.setWidth(length);
    }

    /**
     * Set side for the square.
     *
     * @param width side
     */
    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        super.setLength(width);
    }

    /**
     * Get area.
     *
     * @return double
     */
    @Override
    public double getArea() {
        return 1.0 * width * width;
    }

    /**
     * Get perimeter.
     *
     * @return double
     */
    @Override
    public double getPerimeter() {
        return 4.0 * width;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    /**
     * To string method.
     *
     * @return String
     */

    @Override
    public String toString() {
        return String.format("Square[topLeft=%s,side=%.1f,color=%s,filled=%s]",
                topLeft, width, color, filled);
    }
}

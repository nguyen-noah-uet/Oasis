public class Point {
    private double pointX;
    private double pointY;

    /**
     * Constructor.
     */
    public Point(double pointX, double pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public double getPointX() {
        return pointX;
    }

    public void setPointX(double pointX) {
        this.pointX = pointX;
    }

    public double getPointY() {
        return pointY;
    }

    public void setPointY(double pointY) {
        this.pointY = pointY;
    }

    public double distance(Point another) {
        return Math.sqrt(Math.pow(pointX - another.pointX, 2)
                + Math.pow(pointY - another.pointY, 2));
    }

    /**
     * Compare two points.
     *
     * @param obj another point
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Point) {
            return pointX == ((Point) obj).pointX && pointY == ((Point) obj).pointY;
        }
        return false;
    }

    /**
     * To string method.
     *
     * @return String
     */
    @Override
    public String toString() {
        return String.format("(%.1f,%.1f)", pointX, pointY);
    }
}

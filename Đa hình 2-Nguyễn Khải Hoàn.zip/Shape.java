public abstract class Shape {
    protected String color;
    protected boolean filled;

    /**
     * Constructor.
     */
    public Shape() {

    }

    /**
     * Constructor.
     */
    public Shape(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    /**
     * Get area.
     *
     * @return double
     */
    public abstract double getArea();

    /**
     * Get perimeter.
     *
     * @return double
     */
    public abstract double getPerimeter();

    /**
     * To string method.
     *
     * @return String
     */
    @Override
    public String toString() {
        return String.format("Shape[color=%s,filled=%b]", color, filled);
    }
}

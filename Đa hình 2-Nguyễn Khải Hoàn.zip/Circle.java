public class Circle extends Shape {
    protected double radius;
    protected Point center;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Constructor.
     */
    public Circle() {
    }

    /**
     * Constructor.
     */
    public Circle(double radius) {
        this.radius = radius;
    }

    /**
     * Constructor.
     */
    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    /**
     * Constructor.
     */
    public Circle(Point center, double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
        this.center = center;
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point center) {
        this.center = center;
    }

    /**
     * Get area.
     *
     * @return double
     */
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    /**
     * Get perimeter.
     *
     * @return double
     */
    @Override
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    /**
     * To string method.
     *
     * @return String
     */
    @Override
    public String toString() {
        return String.format("Circle[center=%s,radius=%.1f,color=%s,filled=%s]",
                center, radius, color, filled);
    }

    /**
     * Compare two circles.
     *
     * @param obj another circle
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Circle) {
            return center.equals(((Circle) obj).center) && radius == ((Circle) obj).radius;
        }
        return false;
    }
}

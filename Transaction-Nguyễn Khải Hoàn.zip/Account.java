import java.util.ArrayList;

public class Account {
    private double balance;
    private final ArrayList<Transaction> transitionList;

    public Account() {
        balance = 0;
        transitionList = new ArrayList<>();
    }

    /**
     * Deposit money into your account.
     *
     * @param amount amount you want to deposit (must greater than 0)
     */
    private void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("So tien ban nap vao khong hop le!");
            return;
        }
        balance += amount;
    }

    /**
     * Withdraw money from your account.
     *
     * @param amount amount you want to deposit (must greater than 0 and less than balance)
     */
    private void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("So tien ban rut ra khong hop le!");
            return;
        }
        if (amount > balance) {
            System.out.println("So tien ban rut vuot qua so du!");
            return;
        }
        balance -= amount;
    }

    /**
     * Add a transaction to list of Transaction.
     *
     * @param amount    amount you want to execute operation
     * @param operation operation you want to execute
     */
    public void addTransaction(double amount, String operation) {
        if (operation.equals(Transaction.DEPOSIT)) {
            deposit(amount);
            transitionList.add(new Transaction(operation, amount, balance));
            return;
        }
        if (operation.equals(Transaction.WITHDRAW)) {
            withdraw(amount);
            transitionList.add(new Transaction(operation, amount, balance));
            return;
        }
        // operation invalid
        System.out.println("Yeu cau khong hop le!");
    }

    /**
     * Print all transactions.
     */
    public void printTransaction() {
        int count = 1;
        String operation;
        for (Transaction transaction : transitionList) {
            operation = transaction.getOperation().equals("deposit") ? "Nap tien" : "Rut tien";
            String s = String.format("Giao dich %d: %s $%.2f. So du luc nay: $%.2f.",
                    count++,
                    operation,
                    transaction.getAmount(),
                    transaction.getBalance());
            System.out.println(s);
        }
    }
}

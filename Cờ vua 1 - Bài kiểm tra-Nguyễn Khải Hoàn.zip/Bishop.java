import java.util.ArrayList;

public class Bishop extends Piece {

    public Bishop(int x, int y) {
        super(x, y);
    }

    public Bishop(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public String getSymbol() {
        return "B";
    }

    @Override
    public boolean canMove(Board board, int x, int y) {
        //  Check có đi ra ngoài board không
        if (x > Board.WIDTH || y > Board.HEIGHT || x < 1 || y < 1) {
            return false;
        }

        //  Check có đi theo đường chéo hay không
        if (Math.abs(x - getCoordinatesX()) != Math.abs(y - getCoordinatesY())) {
            return false;
        }

        ArrayList<Piece> pieces = board.getPieces();
        for (Piece piece : pieces) {
            if (piece == this) {
                continue;
            }
            int thisX = getCoordinatesX();
            int thisY = getCoordinatesY();
            int otherX = piece.getCoordinatesX();
            int otherY = piece.getCoordinatesY();
            //  Nếu gặp quân của địch -> có thể kill
            if (!piece.getColor().equals(getColor())
                    && otherX == x && otherY == y) {
                return true;
            }

            System.out.println(thisX + " " + thisY + " " + otherX + " " + otherY
                    + " " + x + " " + y + "\n");

            //  Check bị quân khác chặn
            //  Vector từ quân cờ đến đến đích
            Vector2 v1 = new Vector2(x - thisX, y - thisY);
            //  Vector từ quân cờ đến chướng ngại vật
            Vector2 v2 = new Vector2(otherX - thisX, otherY - thisY);
            //  Vector từ chướng ngại vật đến đích
            Vector2 v3 = new Vector2(x - otherX, y - otherY);
            //  Xét thẳng hàng.
            if (Math.abs(v1.getCoordinatesX() * v2.getCoordinatesX())
                    == Math.abs(v1.getCoordinatesY() * v2.getCoordinatesY())) {
                if (Math.abs(v1.getLength() - v2.getLength() - v3.getLength()) < 0.0001) {
                    return false;
                }
            }
        }
        return true;
    }
}

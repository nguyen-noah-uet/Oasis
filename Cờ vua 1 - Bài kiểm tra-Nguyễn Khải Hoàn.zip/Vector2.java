public class Vector2 {
    private int coordinatesX;
    private int coordinatesY;

    public Vector2(int x, int y) {
        this.coordinatesX = x;
        this.coordinatesY = y;
    }

    public int getCoordinatesX() {
        return coordinatesX;
    }

    public void setCoordinatesX(int coordinatesX) {
        this.coordinatesX = coordinatesX;
    }

    public int getCoordinatesY() {
        return coordinatesY;
    }

    public void setCoordinatesY(int coordinatesY) {
        this.coordinatesY = coordinatesY;
    }

    /**
     * Comment.
     */
    public double getLength() {
        return Math.sqrt(coordinatesX * coordinatesX + coordinatesY * coordinatesY);
    }
}

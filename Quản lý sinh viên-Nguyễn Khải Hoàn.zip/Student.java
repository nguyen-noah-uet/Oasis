public class Student {
    private String id;
    private String name;
    private String group;
    private String email;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInfo() {
        return String.format("%s - %s - %s - %s", name, id, group, email);
    }

    /**
     * Create new Student with default name, id, group, email.
     */
    public Student() {
        name = "Student";
        id = "000";
        group = "K62CB";
        email = "uet@vnu.edu.vn";
    }

    /**
     * Create new Student with name, id, email.
     * @param name name of student.
     * @param id id of student.
     * @param email email of student.
     */
    public Student(String name, String id, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.group = "K62CB";
    }

    /**
     * Copy constructor.
     * @param s the student that want to copy.
     */
    public Student(Student s) {
        id = s.getId();
        name = s.getName();
        group = s.getGroup();
        email = s.getEmail();
    }
}

import java.util.ArrayList;

public class StudentManagement {
    private final Student[] students;
    private int count = 0;

    public StudentManagement() {
        this.students = new Student[100];
    }

    public static boolean sameGroup(Student s1, Student s2) {
        return s1.getGroup().equals(s2.getGroup());
    }

    /**
     * Add new student.
     * @param newStudent : student to be added.
     */
    public void addStudent(Student newStudent) {
        if (count < students.length - 1) {
            students[count] = new Student();
            students[count].setId(newStudent.getId());
            students[count].setName(newStudent.getName());
            students[count].setGroup(newStudent.getGroup());
            students[count].setEmail(newStudent.getEmail());
            count++;
        }
    }

    /**
     * Returns String that contain students list by group.
     * @return String
     */
    public String studentsByGroup() {
        String result = "";
        ArrayList<String> groups = new ArrayList<String>();

        for (int i = 0; i < count; i++) {
            if (!groups.contains(students[i].getGroup())) {
                groups.add(students[i].getGroup());
            }
        }
        for (String group : groups) {
            result += group + "\n";
            for (int i = 0; i < count; i++) {
                if (students[i].getGroup().equals(group)) {
                    result += students[i].getInfo() + "\n";
                }
            }
        }
        return result;
    }

    /**
     * Remove student by id.
     * @param id : id of student that you want to delete.
     */
    public void removeStudent(String id) {
        // find the first student has id == id
        int index = -1;
        for (int i = 0; i < count; i++) {
            if (students[i].getId().equals(id)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return;
        }
        // decrease count by 1 and move all remain students ahead
        count--;
        for (int j = index; j < count; j++) {
            students[j].setId(students[j + 1].getId());
            students[j].setName(students[j + 1].getName());
            students[j].setGroup(students[j + 1].getGroup());
            students[j].setEmail(students[j + 1].getEmail());
        }
    }
}

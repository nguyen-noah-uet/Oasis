public class Person {
    private String name;
    private String address;

    /**
     * Constructor.
     *
     * @param name    name
     * @param address address
     */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Get value in string.
     *
     * @return String
     */
    @Override
    public String toString() {
        return String.format("Person[name=%s,address=%s]", name, address);
    }
}

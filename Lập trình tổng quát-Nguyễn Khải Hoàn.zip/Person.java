import java.util.ArrayList;
import java.util.List;

public class Person implements Comparable<Person> {
    private String name;
    private int age;
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Person() {
    }

    /**
     * Constructor.
     * @param name name
     * @param age age
     * @param address address
     */
    public Person(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    /**
     * Compare.
     * @param another the object to be compared.
     * @return int
     */
    @Override
    public int compareTo(Person another) {
        if (this.name.compareTo(another.name) == 0) {
            return this.age - another.age;
        }
        return this.name.compareTo(another.name);
    }

}

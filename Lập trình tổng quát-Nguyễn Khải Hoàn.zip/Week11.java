import java.util.Collections;
import java.util.List;

public class Week11 {
    /**
     * Sort generic list.
     * @param list list
     * @param <T> generic parameter
     * @return list
     */
    public static <T extends Comparable<T>> List<T> sortGeneric(List<T> list)  {
        Collections.sort(list);
        return list;
    }
}

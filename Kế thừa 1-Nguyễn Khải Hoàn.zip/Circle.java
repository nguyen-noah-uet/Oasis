public class Circle {
    protected static final double PI = Math.PI;
    private double radius = 1.0d;
    private String color = "red";

    /**
     * Default constructor.
     */
    public Circle() {

    }

    /**
     * Constructor.
     *
     * @param radius radius
     */
    public Circle(double radius) {
        this.radius = radius;
    }

    /**
     * Constructor.
     *
     * @param radius radius
     * @param color  color
     */
    public Circle(double radius, String color) {
        this.radius = radius;
        this.color = color;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Get area of circle.
     *
     * @return double
     */
    public double getArea() {
        return Circle.PI * radius * radius;
    }

    /**
     * Get value in string.
     *
     * @return String
     */
    @Override
    public String toString() {
        return String.format("Circle[radius=%f,color=%f]", radius, color);
    }
}

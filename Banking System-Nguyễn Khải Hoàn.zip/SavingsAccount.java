
public class SavingsAccount extends Account {

    /**
     * Comment.
     */
    public SavingsAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void withdraw(double amount) {
        try {
            doWithdrawing(amount);
            transactionList.add(new Transaction(Transaction.TYPE_WITHDRAW_SAVINGS,
                    amount, balance + amount, balance));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deposit(double amount) {
        try {
            doDepositing(amount);
            addTransaction(new Transaction(Transaction.TYPE_DEPOSIT_SAVINGS,
                    amount, balance - amount, balance));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void doWithdrawing(double amount) throws InsufficientFundsException,
            InvalidFundingAmountException {
        if (amount < 0) {
            throw new InvalidFundingAmountException(amount);
        } else if (balance - amount < 5000
                || amount > 1000) {
            throw new InsufficientFundsException(amount);
        } else {
            balance -= amount;
        }
    }
}

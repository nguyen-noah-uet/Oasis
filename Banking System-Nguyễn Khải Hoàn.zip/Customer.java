import java.util.ArrayList;
import java.util.List;

public class Customer {
    private long idNumber;
    private String fullName;
    private List<Account> accountList = new ArrayList<>();

    public Customer() {
        idNumber = 0;
        fullName = "";
    }

    /**
     * Comment.
     */
    public Customer(long idNumber, String fullName) {
        this.idNumber = idNumber;
        this.fullName = fullName;
    }

    /**
     * Comment.
     */
    public String getCustomerInfo() {
        String s = new String();
        s += "Số CMND: " + idNumber;
        s += ". Họ tên: " + fullName + ".";
        return s;
    }

    /**
     * Comment.
     */
    public void addAccount(Account account) {
        for (Account acc : accountList) {
            if (acc.equals(account)) {
                return;
            }
        }
        accountList.add(account);
    }

    /**
     * Comment.
     */
    public void removeAccount(Account account) {
        for (int i = 0; i < accountList.size(); i++) {
            Account acc = accountList.get(i);
            if (acc.equals(account)) {
                accountList.remove(i);
                i--;
            }
        }
    }


    public long getIdNumber() {
        return idNumber;
    }


    public void setIdNumber(long idNumber) {
        this.idNumber = idNumber;
    }


    public String getFullName() {
        return fullName;
    }


    public void setFullName(String fullName) {
        this.fullName = fullName;
    }


    public List<Account> getAccountList() {
        return accountList;
    }

    @Override
    public String toString() {
        return String.format("Số CMND: %d. Họ tên: %s.", idNumber, fullName);
    }
}

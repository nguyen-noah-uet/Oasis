
public class InvalidFundingAmountException extends BankException {
    /**
     * blabla.
     */
    public InvalidFundingAmountException(Double amount) {
        super("Số tiền không hợp lệ: $"
                + String.format("%.2f", amount));
    }
}

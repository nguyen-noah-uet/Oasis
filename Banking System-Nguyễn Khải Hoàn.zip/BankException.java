
public class BankException extends Exception {
    /**
     * Comment.
     */
    public BankException(String message) {
        super(message);
    }
}

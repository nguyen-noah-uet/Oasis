
public class CheckingAccount extends Account {

    /**
     * Comment.
     */
    public CheckingAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void withdraw(double amount) {
        try {
            doWithdrawing(amount);
            transactionList.add(new Transaction(Transaction.TYPE_WITHDRAW_CHECKING,
                    amount, balance + amount, balance));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deposit(double amount) {
        try {
            doDepositing(amount);
            addTransaction(new Transaction(Transaction.TYPE_DEPOSIT_CHECKING,
                    amount, balance - amount, balance));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

public class Solution {
    private int numerator;
    private int denominator;

    public int getNumerator() {
        return numerator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public int getDenominator() {
        return denominator;
    }

    /**
     * Set denominator if <code>denominator</code> not equals to 0.
     */
    public void setDenominator(int denominator) {
        if (denominator != 0) {
            this.denominator = denominator;
        }
    }

    /**
     * Calculate gcd of 2 integers.
     *
     * @param a first number
     * @param b second number
     * @return int
     */
    public int gcd(int a, int b) {
        a = (a > 0) ? a : -a;
        b = (b > 0) ? b : -b;

        return b == 0 ? a : gcd(b, a % b);
    }


    /**
     * Reduce current fraction.
     *
     * @return Solution
     */
    public Solution reduce() {
        int gcd = gcd(this.numerator, this.denominator);
        this.numerator /= gcd;
        this.denominator /= gcd;
        if (this.denominator < 0) {
            this.numerator *= -1;
            this.denominator *= -1;
        }
        return this;
    }

    /**
     * Add current fraction with another fraction.
     *
     * @param another another fraction.
     * @return Solution
     */
    public Solution add(Solution another) {
        int newNumerator;
        newNumerator = numerator * another.getDenominator() + denominator * another.getNumerator();
        int newDenominator;
        newDenominator = this.denominator * another.getDenominator();
        this.numerator = newNumerator;
        this.denominator = newDenominator;
        return this.reduce();
    }

    /**
     * Subtract current fraction with another fraction.
     *
     * @param another another fraction.
     * @return Solution
     */
    public Solution subtract(Solution another) {
        int newNumerator;
        newNumerator = numerator * another.getDenominator() - denominator * another.getNumerator();
        int newDenominator;
        newDenominator = this.denominator * another.getDenominator();
        this.numerator = newNumerator;
        this.denominator = newDenominator;
        return this.reduce();
    }

    /**
     * Multiply current fraction with another fraction.
     *
     * @param another another fraction.
     * @return Solution
     */
    public Solution multiply(Solution another) {
        int newNumerator = this.numerator * another.getNumerator();
        int newDenominator = this.denominator * another.getDenominator();
        this.numerator = newNumerator;
        this.denominator = newDenominator;
        return this.reduce();
    }

    /**
     * Divide current fraction with another fraction.
     *
     * @param another another fraction.
     * @return Solution
     */
    public Solution divide(Solution another) {
        int newNumerator = this.numerator * another.getDenominator();
        int newDenominator = this.denominator * another.getNumerator();
        this.numerator = newNumerator;
        this.denominator = newDenominator;
        return this.reduce();
    }

    /**
     * Check if current fraction equals another.
     *
     * @param obj another fraction
     * @return boolean
     */
    public boolean equals(Object obj) {
        if (obj instanceof Solution) {
            Solution s = (Solution) obj;
            this.reduce();
            s.reduce();
            return this.numerator == s.getNumerator() && this.denominator == s.getDenominator();
        }
        return false;
    }

    /**
     * Constructor.
     *
     * @param numerator   numerator
     * @param denominator denominator
     */
    public Solution(int numerator, int denominator) {
        this.numerator = numerator;
        this.denominator = (denominator != 0) ? denominator : 1;
    }

    public String toString() {
        return String.format("%d/%d", this.numerator, this.denominator);
    }

//    public static void main(String[] args) {
//        Solution s0 = new Solution(1, 2);
//        Solution s1 = new Solution(2, 7);
//        Solution s2 = new Solution(3, 4);
//        Solution s3 = new Solution(2, -7);
//        Solution s4 = new Solution(21, 17);
//        Solution s5 = new Solution(20, -7);
//        Solution s6 = new Solution(3, 4);
//        Solution s7 = new Solution(0, 5);
//        Solution s8 = new Solution(8, 7);
//        System.out.println(s0.add(s1).toString());
//        System.out.println(s2.subtract(s3).toString());
//        System.out.println(s4.multiply(s5).toString());
//        System.out.println(s6.divide(s7).toString());
//    }
}

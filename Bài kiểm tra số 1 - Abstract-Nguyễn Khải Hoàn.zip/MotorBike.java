public class MotorBike extends Vehicle {
    private boolean hasSidecar;

    /**
     * Constructor.
     *
     * @param brand              brand
     * @param model              model
     * @param registrationNumber registrationNumber
     * @param owner              owner
     */
    public MotorBike(String brand,
                     String model,
                     String registrationNumber,
                     Person owner,
                     boolean hasSidecar) {
        super(brand, model, registrationNumber, owner);
        this.hasSidecar = hasSidecar;
    }

    public boolean isHasSidecar() {
        return hasSidecar;
    }

    public void setHasSidecar(boolean hasSidecar) {
        this.hasSidecar = hasSidecar;
    }

    /**
     * Get info.
     *
     * @return String
     */
    @Override
    public String getInfo() {
        StringBuilder sb = new StringBuilder("Motor Bike:\n");
        sb.append(String.format("\tBrand: %s\n", brand));
        sb.append(String.format("\tModel: %s\n", model));
        sb.append(String.format("\tRegistration Number: %s\n", registrationNumber));
        sb.append(String.format("\tHas Side Car: %b\n", hasSidecar));
        sb.append(String.format("\tBelongs to %s\n", owner.toString()));
        return sb.toString();
    }
}

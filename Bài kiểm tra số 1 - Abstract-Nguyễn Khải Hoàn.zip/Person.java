import java.util.ArrayList;
import java.util.List;

public class Person {
    private String name;
    private String address;
    private final List<Vehicle> vehicleList;

    /**
     * Constructor.
     *
     * @param name    name
     * @param address address
     */
    public Person(String name, String address) {
        this.name = name;
        this.address = address;
        vehicleList = new ArrayList<>();
    }

    /**
     * Remove a vehicle.
     *
     * @param registrationNumber registrationNumber
     */
    public void removeVehicle(String registrationNumber) {
        vehicleList.removeIf(v -> v.registrationNumber.equals(registrationNumber));
    }

    /**
     * Add vehicle.
     *
     * @param vehicle vehicle
     */
    public void addVehicle(Vehicle vehicle) {
        vehicle.setOwner(this);
        vehicleList.add(vehicle);
    }

    /**
     * Get vehicles info of a person.
     *
     * @return String
     */
    public String getVehiclesInfo() {
        if (vehicleList.isEmpty()) {
            return String.format("%s has no vehicle!", name);
        }
        StringBuilder sb = new StringBuilder(String.format("%s has:\n\n", name));
        for (Vehicle vehicle : vehicleList) {
            sb.append(vehicle.getInfo());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("%s - %s", name, address);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

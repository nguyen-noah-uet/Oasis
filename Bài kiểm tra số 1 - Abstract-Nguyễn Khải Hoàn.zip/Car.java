public class Car extends Vehicle {
    private int numberOfDoors;

    /**
     * Constructor.
     *
     * @param brand              brand
     * @param model              model
     * @param registrationNumber registrationNumber
     * @param owner              owner
     */
    public Car(String brand,
               String model,
               String registrationNumber,
               Person owner,
               int numberOfDoors) {
        super(brand, model, registrationNumber, owner);
        this.numberOfDoors = numberOfDoors;
    }

    /**
     * Get info.
     *
     * @return String
     */
    @Override
    public String getInfo() {
        StringBuilder sb = new StringBuilder("Car:\n");
        sb.append(String.format("\tBrand: %s\n", brand));
        sb.append(String.format("\tModel: %s\n", model));
        sb.append(String.format("\tRegistration Number: %s\n", registrationNumber));
        sb.append(String.format("\tNumber of Doors: %d\n", numberOfDoors));
        sb.append(String.format("\tBelongs to %s\n", owner.toString()));
        return sb.toString();
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }

    public void setNumberOfDoors(int numberOfDoors) {
        this.numberOfDoors = numberOfDoors;
    }
}

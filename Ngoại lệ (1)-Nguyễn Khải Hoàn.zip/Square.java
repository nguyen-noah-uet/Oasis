public class Square extends Expression {
    private final Expression expression;

    /**
     * Constructor.
     */
    public Square(Expression expression) {
        this.expression = expression;
    }

    /**
     * To String method.
     *
     * @return String
     */
    @Override
    public String toString() {
        if (expression instanceof Numeral) {
            return String.format("(%s) ^ 2", expression);
        }
        return String.format("((%s)) ^ 2", expression);
    }

    /**
     * Evaluate expression.
     *
     * @return double
     */
    @Override
    public double evaluate() {
        return expression.evaluate() * expression.evaluate();
    }
}

public abstract class Expression {

    /**
     * To String method.
     *
     * @return String
     */
    @Override
    public abstract String toString();

    /**
     * Evaluate expression.
     *
     * @return double
     */
    public abstract double evaluate();
}

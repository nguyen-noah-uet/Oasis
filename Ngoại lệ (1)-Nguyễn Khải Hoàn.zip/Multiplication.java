public class Multiplication extends BinaryExpression {
    /**
     * Constructor.
     */
    public Multiplication(Expression left, Expression right) {
        super(left, right);
    }

    /**
     * To String method.
     *
     * @return String
     */
    @Override
    public String toString() {
        String leftString = (left instanceof Numeral || left instanceof Square)
                ? left.toString() : String.format("(%s)", left.toString());
        String rightString = (right instanceof Numeral || right instanceof Square)
                ? right.toString() : String.format("(%s)", right.toString());
        return String.format("%s * %s", leftString, rightString);
    }

    /**
     * Evaluate expression.
     *
     * @return double
     */
    @Override
    public double evaluate() {
        return left.evaluate() * right.evaluate();
    }

}

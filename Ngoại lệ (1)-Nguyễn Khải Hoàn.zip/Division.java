public class Division extends BinaryExpression {
    /**
     * Constructor.
     */
    public Division(Expression left, Expression right) {
        super(left, right);
    }

    /**
     * To String method.
     *
     * @return String
     */
    @Override
    public String toString() {
        String leftString = (left instanceof Numeral || left instanceof Square)
                ? left.toString() : String.format("(%s)", left.toString());
        String rightString = (right instanceof Numeral || right instanceof Square)
                ? right.toString() : String.format("(%s)", right.toString());
        return String.format("%s / %s", leftString, rightString);
    }

    /**
     * Evaluate expression.
     *
     * @return double
     */
    @Override
    public double evaluate() {
        if (right.evaluate() == 0) {
            throw new ArithmeticException("Lỗi chia cho 0");
        }
        return left.evaluate() / right.evaluate();
    }

}

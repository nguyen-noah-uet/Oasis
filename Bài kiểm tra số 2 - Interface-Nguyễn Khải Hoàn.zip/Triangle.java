public class Triangle implements GeometricObject {
    private Point p1;
    private Point p2;
    private Point p3;
    private double p1top2;
    private double p2top3;
    private double p3top1;

    /**
     * Comment.
     */
    public Triangle(Point p1, Point p2, Point p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        p1top2 = Point.distance(p1, p2);
        p2top3 = Point.distance(p2, p3);
        p3top1 = Point.distance(p3, p1);
        if (p1top2 == 0 || p2top3 == 0 || p3top1 == 0) {
            throw new RuntimeException();
        }
        if (p1top2 + p2top3 == p3top1 || p1top2 + p3top1 == p2top3) {
            throw new RuntimeException();
        }
    }

    public Point getP1() {
        return p1;
    }

    public Point getP2() {
        return p2;
    }

    public Point getP3() {
        return p3;
    }

    /**
     * Comment.
     */
    public double getArea() {
        double halfOfPerimeter = getPerimeter() / 2;
        return
                Math.sqrt(halfOfPerimeter
                        * (halfOfPerimeter - p1top2)
                        * (halfOfPerimeter - p2top3)
                        * (halfOfPerimeter - p3top1));
    }

    @Override
    public double getPerimeter() {
        return p1top2 + p2top3 + p3top1;
    }


    /**
     * Comment.
     */
    public String getInfo() {
        return String.format("Triangle[%s,%s,%s]", p1.toString(), p2.toString(), p3.toString());
    }
}
 
public class Point {
    private double pointX;
    private double pointY;

    /**
     * Comment.
     */
    public Point(double x, double y) {
        this.pointX = x;
        this.pointY = y;
    }

    /**
     * Comment.
     */
    public static double distance(Point p1, Point p2) {
        return Math.sqrt((p1.pointX - p2.pointX) * (p1.pointX - p2.pointX)
                + (p1.pointY - p2.pointY) * (p1.pointY - p2.pointY));
    }

    public double getPointX() {
        return pointX;
    }

    public void setPointX(double x) {
        this.pointX = x;
    }

    public double getPointY() {
        return pointY;
    }

    public void setPointY(double y) {
        this.pointY = y;
    }

    @Override
    public String toString() {
        return String.format("(%.2f,%.2f)", pointX, pointY);
    }
}
 
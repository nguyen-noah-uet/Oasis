import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ShapeUtil {

    /**
     * Comment.
     */
    public String printInfo(List<GeometricObject> listGeometricObject) {
        List<GeometricObject> circles = listGeometricObject
                .stream().filter(o -> o instanceof Circle).collect(Collectors.toList());
        List<GeometricObject> triangles = listGeometricObject
                .stream().filter(o -> o instanceof Triangle).collect(Collectors.toList());
        String result = "";

        if (circles.size() > 0) {
            result += "Circle:" + "\n";
            for (GeometricObject circle : circles) {
                result += circle.getInfo() + "\n";
            }
        }

        if (triangles.size() > 0) {
            result += "Triangle:" + "\n";
            for (GeometricObject circle : triangles) {
                result += circle.getInfo() + "\n";
            }
        }
        return result;
    }
} 
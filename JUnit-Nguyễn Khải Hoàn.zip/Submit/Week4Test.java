import org.junit.Assert;
import org.junit.Test;

public class Week4Test {
    @Test
    public void max2Int_test1() {
        int actualResult = Week4.max2Int(12,22);
        int expected = 22;
        Assert.assertEquals(actualResult, expected);
    }
    @Test
    public void max2Int_test2() {
        int actualResult = Week4.max2Int(Integer.MAX_VALUE,Integer.MIN_VALUE);
        int expected = Integer.MAX_VALUE;
        Assert.assertEquals(actualResult, expected);
    }
    @Test
    public void max2Int_test3() {
        int actualResult = Week4.max2Int(Integer.MAX_VALUE,Integer.MAX_VALUE);
        int expected = Integer.MAX_VALUE;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void max2Int_test4() {
        int actualResult = Week4.max2Int(-1,1);
        int expected = 1;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void max2Int_test5() {
        int actualResult = Week4.max2Int(-10,-11);
        int expected = -10;
        Assert.assertEquals(actualResult, expected);
    }
    @Test
    public void minArray_test1() {
        int[] array = new int[] {1,2,3,3};
        int actualResult = Week4.minArray(array);
        int expected = 1;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void minArray_test2() {
        int[] array = new int[] {0,-12,3,3};
        int actualResult = Week4.minArray(array);
        int expected = -12;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void minArray_test3() {
        int[] array = new int[] {1,1,1,1};
        int actualResult = Week4.minArray(array);
        int expected = 1;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void minArray_test4() {
        int[] array = new int[] {Integer.MIN_VALUE,2,3,3};
        int actualResult = Week4.minArray(array);
        int expected = Integer.MIN_VALUE;
        Assert.assertEquals(expected, actualResult);
    }

    @Test
    public void minArray_test5() {
        int[] array = new int[] {100};
        int actualResult = Week4.minArray(array);
        int expected = 100;
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void calculateBMI_test1() {
        String actualResult = Week4.calculateBMI(50, 1.5);
        String expected = "Bình thường";
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void calculateBMI_test2() {
        String actualResult = Week4.calculateBMI(60, 1.56);
        String expected = "Thừa cân";
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void calculateBMI_test3() {
        String actualResult = Week4.calculateBMI(45, 1.58);
        String expected = "Thiếu cân";
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void calculateBMI_test4() {
        String actualResult = Week4.calculateBMI(70, 1.6);
        String expected = "Béo phì";
        Assert.assertEquals(expected, actualResult);
    }
    @Test
    public void calculateBMI_test5() {
        String actualResult = Week4.calculateBMI(70, 1.7);
        String expected = "Thừa cân";
        Assert.assertEquals(expected, actualResult);
    }
}

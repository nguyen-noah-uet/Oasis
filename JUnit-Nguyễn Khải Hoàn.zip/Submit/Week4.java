import java.util.Arrays;

public class Week4 {
    public static int max2Int(int num1, int num2) {
        return Math.max(num1, num2);
    }
    public static int minArray(int[] array){
        return Arrays.stream(array).min().getAsInt();
    }
    public static String calculateBMI(double weight, double height){
        double bmi = weight / (height * height);
        bmi = Double.parseDouble(String.format("%.1f", bmi).replace(',','.'));
        if (bmi < 18.5d) {
            return "Thiếu cân";
        }
        else if (bmi >= 18.5 && bmi <= 22.9) {
            return "Bình thường";
        }
        else if (bmi >= 23 && bmi <= 24.9) {
            return "Thừa cân";
        }
        else {
            return "Béo phì";
        }
    }
}

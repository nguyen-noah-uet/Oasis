public abstract class Piece {
    private int coordinatesX;
    private int coordinatesY;
    private String color;

    /**
     * Constructor.
     */
    public Piece(int x, int y) {
        this.coordinatesX = x;
        this.coordinatesY = y;
        color = "white";
    }

    /**
     * Constructor.
     */
    public Piece(int x, int y, String color) {
        this.coordinatesX = x;
        this.coordinatesY = y;
        this.color = color;
    }


    public void setColor(String color) {
        this.color = color;
    }


    public String getColor() {
        return color;
    }


    public void setCoordinatesX(int coordinatesX) {
        this.coordinatesX = coordinatesX;
    }


    public int getCoordinatesX() {
        return coordinatesX;
    }


    public void setCoordinatesY(int coordinatesY) {
        this.coordinatesY = coordinatesY;
    }


    public int getCoordinatesY() {
        return coordinatesY;
    }


    public abstract String getSymbol();

    /**
     * Comment.
     */
    public abstract boolean canMove(Board board, int x, int y);

    /**
     * Comment.
     */
    public boolean equalsCoordinates(Piece other) {
        return coordinatesX == other.coordinatesX && coordinatesY == other.coordinatesY;
    }

    public boolean checkPosition(Piece other) {
        return coordinatesX == other.coordinatesX && coordinatesY == other.coordinatesY;
    }
}

import java.util.ArrayList;

public class Rook extends Piece {
    /**
     * Constructor.
     */
    public Rook(int x, int y) {
        super(x, y);
    }

    /**
     * Constructor.
     */
    public Rook(int x, int y, String color) {
        super(x, y, color);
    }

    @Override
    public String getSymbol() {
        return "R";
    }

    /**
     * Comment.
     */
    @Override
    public boolean canMove(Board board, int x, int y) {
        //  Check ở trong board
        if (x > Board.WIDTH || y > Board.HEIGHT || x < 1 || y < 1) {
            return false;
        }

        //  Check không đi theo đường ngang hoặc dọc
        if (getCoordinatesX() != x && getCoordinatesY() != y) {
            return false;
        }

        ArrayList<Piece> pieces = board.getPieces();
        for (int i = 0; i < pieces.size(); ++i) {
            if (this.equals(pieces.get(i))) {
                continue;
            }
            Piece piece = pieces.get(i);
            int thisX = getCoordinatesX();
            int thisY = getCoordinatesY();
            int otherX = piece.getCoordinatesX();
            int otherY = piece.getCoordinatesY();
            //  Nếu gặp quân của địch -> có thể kill
            if (!piece.getColor().equals(getColor())
                && otherX == x && otherY == y) {
                return true;
            }
            //  Nếu trên đường dọc bị cản -> không đi được
            if (otherX == thisX
                && (otherY > thisY && otherY <= y
                || otherY < thisY && otherY >= y)) {
                return false;
            }
            //  Nếu trên đường ngang bị cản -> không đi được
            if (otherY == thisY
                    && (otherX > thisX && otherX <= x
                    || otherX < thisX && otherX >= x)) {
                return false;
            }
        }
        return true;
    }
}

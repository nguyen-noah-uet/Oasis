import java.util.ArrayList;

public class Game {
    private Board board;
    private ArrayList<Move> moveHistory;

    /**
     * Constructor.
     */
    public Game(Board board) {
        this.board = board;
        moveHistory = new ArrayList<Move>();
    }

    /**
     * Comment.
     */
    public void movePiece(Piece piece, int x, int y) {
        if (piece.canMove(board, x, y)) {
            Move move = new Move(piece.getCoordinatesX(),
                    piece.getCoordinatesY(),
                    x, y, piece);
            ArrayList<Piece> piecesInBoard = board.getPieces();
            for (int i = 0; i < piecesInBoard.size(); ++i) {
                if (piecesInBoard.get(i).getCoordinatesX() == x
                        && piecesInBoard.get(i).getCoordinatesY() == y) {
                    move.setKilledPiece(piecesInBoard.get(i));
                    piecesInBoard.remove(i);
                    break;
                }
            }
            moveHistory.add(move);
            piece.setCoordinatesX(x);
            piece.setCoordinatesY(y);
        }
    }

    public ArrayList<Move> getMoveHistory() {
        return moveHistory;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public Board getBoard() {
        return board;
    }
}

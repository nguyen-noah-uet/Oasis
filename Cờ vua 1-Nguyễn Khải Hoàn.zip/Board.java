import java.util.ArrayList;

public class Board {
    public static final int WIDTH = 8;
    public static final int HEIGHT = 8;
    private ArrayList<Piece> pieces;

    /**
     * Constructor.
     */
    public Board() {
        pieces = new ArrayList<Piece>();
    }

    /**
     * Comment.
     */
    public void addPiece(Piece piece) {
        if (!validate(piece.getCoordinatesX(), piece.getCoordinatesY())) {
            return;
        }
        for (Piece value : pieces) {
            if (value.equalsCoordinates(piece)) {
                return;
            }
        }
        pieces.add(piece);
    }

    /**
     * Comment.
     */
    public boolean validate(int x, int y) {
        return x >= 1 && x <= WIDTH && y >= 1 && y <= HEIGHT;
    }

    /**
     * Comment.
     */
    public Piece getAt(int x, int y) {
        for (Piece piece : pieces) {
            if (x == piece.getCoordinatesX() && y == piece.getCoordinatesY()) {
                return piece;
            }
        }
        return null;
    }

    /**
     * Comment.
     */
    public void removeAt(int x, int y) {
        for (int i = 0; i < pieces.size(); ++i) {
            if (x == pieces.get(i).getCoordinatesX() && y == pieces.get(i).getCoordinatesY()) {
                pieces.remove(i);
                return;
            }
        }
    }

    public void setPieces(ArrayList<Piece> pieces) {
        this.pieces = pieces;
    }

    public ArrayList<Piece> getPieces() {
        return pieces;
    }
}
